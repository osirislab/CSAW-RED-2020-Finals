class Prod(object):
    #SECRET_KEY#
    DOMAIN = 'red.chal.csaw.io'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///photos.db'
